# Vagrant box for Crowbar admin node

## Building the box

**N.B. [These instructions are now obsolete!](../README.md)**

First you need to build the `.vmdk` as detailed in
[the README for the corresponding KIWI appliance](../../../kiwi/cloud-admin/README.md).

Then, `cd` to the directory containing this README, and type:

    make

This will create the `.box` file in the current directory, which you
can then install the Vagrant box via:

    vagrant box add cloud-admin.json
